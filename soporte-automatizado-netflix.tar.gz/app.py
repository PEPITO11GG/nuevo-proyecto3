import os
import json
import base64
import requests
from flask import Flask, render_template, request, jsonify
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SESSION_SECRET', 'dev-secret-key-change-in-production')

NETFLIX_CONFIG = {
    'sender': 'info@account.netflix.com',
    'subjects': {
        'verificacion': 'Código de verificación de Netflix',
        'hogar': 'Actualiza tu Hogar de Netflix'
    }
}


def get_gmail_access_token():
    """
    Obtiene el access_token de la integración de Gmail de Replit.
    Utiliza la API de conexiones de Replit.
    """
    hostname = os.getenv('REPLIT_CONNECTORS_HOSTNAME')
    
    x_replit_token = None
    repl_identity = os.getenv('REPL_IDENTITY')
    web_repl_renewal = os.getenv('WEB_REPL_RENEWAL')
    
    if repl_identity:
        x_replit_token = 'repl ' + repl_identity
    elif web_repl_renewal:
        x_replit_token = 'depl ' + web_repl_renewal
    
    if not x_replit_token or not hostname:
        raise Exception('No se pudo obtener el token de autenticación de Replit')
    
    url = f'https://{hostname}/api/v2/connection?include_secrets=true&connector_names=google-mail'
    
    headers = {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': x_replit_token
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        raise Exception(f'Error al obtener credenciales de Gmail: {response.status_code}')
    
    data = response.json()
    items = data.get('items', [])
    
    if not items:
        raise Exception('Gmail no está conectado. Por favor, conecta Gmail en el panel de Integraciones de Replit.')
    
    connection_settings = items[0]
    access_token = connection_settings.get('settings', {}).get('access_token')
    
    if not access_token:
        oauth_creds = connection_settings.get('settings', {}).get('oauth', {}).get('credentials', {})
        access_token = oauth_creds.get('access_token')
    
    if not access_token:
        raise Exception('No se pudo obtener el access_token de Gmail')
    
    return access_token


def get_gmail_service():
    """
    Crea un cliente de Gmail API usando el access_token de la integración de Replit.
    """
    access_token = get_gmail_access_token()
    
    credentials = Credentials(token=access_token)
    service = build('gmail', 'v1', credentials=credentials)
    
    return service


def extract_message_body(payload):
    """
    Función recursiva para extraer el cuerpo del mensaje de Gmail.
    Navega por la estructura MIME y decodifica text/plain o text/html.
    """
    mime_type = payload.get('mimeType', '')
    
    if mime_type in ['text/plain', 'text/html']:
        body_data = payload.get('body', {}).get('data', '')
        if body_data:
            padding_needed = len(body_data) % 4
            if padding_needed:
                body_data += '=' * (4 - padding_needed)
            decoded_bytes = base64.urlsafe_b64decode(body_data)
            return decoded_bytes.decode('utf-8', errors='ignore')
    
    parts = payload.get('parts', [])
    for part in parts:
        result = extract_message_body(part)
        if result:
            return result
    
    return None


@app.route('/')
def index():
    """Página principal de la aplicación"""
    try:
        get_gmail_access_token()
        authenticated = True
    except:
        authenticated = False
    
    return render_template('index.html', authenticated=authenticated)


@app.route('/api/verify', methods=['POST'])
def verify_email():
    """
    Busca correos de Netflix según el tipo especificado.
    Recibe: {email: str, type: str}
    type puede ser 'verificacion' o 'hogar'
    """
    data = request.json
    if not data:
        return jsonify({'error': 'Datos de solicitud no válidos'}), 400
    
    user_email = data.get('email', '')
    search_type = data.get('type', 'verificacion')
    
    if search_type not in NETFLIX_CONFIG['subjects']:
        return jsonify({'error': f'Tipo de búsqueda no válido: {search_type}'}), 400
    
    try:
        service = get_gmail_service()
        
        sender = NETFLIX_CONFIG['sender']
        subject = NETFLIX_CONFIG['subjects'][search_type]
        
        query = f'from:{sender} subject:"{subject}"'
        if user_email:
            query += f' to:{user_email}'
        
        results = service.users().messages().list(
            userId='me',
            q=query,
            maxResults=1
        ).execute()
        
        messages = results.get('messages', [])
        
        if not messages:
            return jsonify({
                'status': 'not_found',
                'message': 'No se encontraron correos que coincidan con la búsqueda'
            })
        
        message_id = messages[0]['id']
        
        message = service.users().messages().get(
            userId='me',
            id=message_id,
            format='full'
        ).execute()
        
        headers = message['payload']['headers']
        subject_header = next((h['value'] for h in headers if h['name'].lower() == 'subject'), 'Sin asunto')
        from_header = next((h['value'] for h in headers if h['name'].lower() == 'from'), 'Desconocido')
        
        body = extract_message_body(message['payload'])
        
        return jsonify({
            'status': 'success',
            'subject': subject_header,
            'from': from_header,
            'snippet': message.get('snippet', ''),
            'body': body or 'No se pudo extraer el cuerpo del mensaje'
        })
        
    except Exception as e:
        error_message = str(e)
        if 'Gmail no está conectado' in error_message:
            return jsonify({
                'error': 'Gmail no está conectado. Por favor, conecta Gmail en el panel de Integraciones de Replit.'
            }), 401
        return jsonify({
            'error': f'Error al buscar correos: {error_message}'
        }), 500


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
